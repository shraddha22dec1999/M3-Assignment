package com.sunsoft.exceptions;

public class ApplicationException extends RuntimeException {

    public ApplicationException(String arg) {
        super(arg);
        System.err.println(arg);
        
    }

}